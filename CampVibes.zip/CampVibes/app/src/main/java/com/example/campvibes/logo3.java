package com.example.campvibes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class logo3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logo3);
    }
    public void startNewActivity(View v){
        Intent intent = new Intent(this, logo4.class);
        startActivity(intent);
    }
}